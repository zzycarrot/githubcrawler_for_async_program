```bash
python clone.py
```

更改`CloneRepo()`中名字 eg. `cloning = CloneRepo("Callback")`从不同的txt来克隆代码

AsyncRepos,CallbackRepos,PromiseRepos是按照每种异步语法出现次数最多归类的，只需要分别clone这三个就可以

